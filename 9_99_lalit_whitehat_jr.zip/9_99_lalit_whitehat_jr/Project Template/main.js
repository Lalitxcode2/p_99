var SpeechRecognition=window.webkitSpeechRecognition;
var recognise= new SpeechRecognition();

function start1(){
    recognise.start();
}

recognise.onresult=function(event){
    console.log(event);
    var content = event.results[0][0].transcript;
    document.getElementById("voice_output").innerHTML = content;
    console.log(content);
    if(content == "Take my selfie."){
        console.log("taking selfie");
        speak();
    }
}

function speak(){
    var speech = window.speechSynthesis;
    var speak_data = "taking your selfie in 5 seconds";

    var utterThis = new SpeechSynthesisUtterance(speak_data);
    speech.speak(utterThis);
    Webcam.attach(webcam);

    setTimeout(function()
    {
        capture();
        download();
    },5000);
}
var webcam = document.getElementById("webcam");
Webcam.set({
    width: 360,
    height: 250,
    image_format: 'jpeg',
    jpeg_quality: 90
 });

 function capture(){
    Webcam.snap(function(selfie) {
        document.getElementById("result1").innerHTML = '<img id="snapshot" src="'+selfie+'">';
    });
 }

 function download(){
    link=document.getElementById("download");
    img=document.getElementById("snapshot").src;
    link.href=img;
    link.click();
 }

var SpeechRecognition=window.webkitSpeechRecognition;
var recognise= new SpeechRecognition();

function start1(){
    recognise.start();
}

recognise.onresult=function(event){
    console.log(event);
    var content = event.results[0][0].transcript;
    document.getElementById("voice_output").innerHTML = content;
    console.log(content);
    if(content == "Take my selfie."){
        console.log("taking selfie");
        speak();
    }
}

function speak(){
    var speech = window.speechSynthesis;
    var speak_data = "taking your selfie in 5 seconds";

    var utterThis = new SpeechSynthesisUtterance(speak_data);
    speech.speak(utterThis);
    Webcam.attach(webcam);

    setTimeout(function()
    {
        capture();
        download();
    },5000);
}
var webcam = document.getElementById("webcam");
Webcam.set({
    width: 360,
    height: 250,
    image_format: 'jpeg',
    jpeg_quality: 90
 });

 function capture(){
    Webcam.snap(function(selfie) {
        document.getElementById("result1").innerHTML = '<img id="snapshot" src="'+selfie+'">';
    });
 }

 function download(){
    link=document.getElementById("download");
    img=document.getElementById("snapshot").src;
    link.href=img;
    link.click();
 }



 var SpeechRecognition2=window.webkitSpeechRecognition;
var recognise2= new SpeechRecognition2();

function start2(){
    recognise2.start();
}

recognise2.onresult=function(event){
    console.log(event);
    var content2 = event.results[0][0].transcript;
    document.getElementById("voice_output").innerHTML = content2;
    console.log(content2);
    if(content2 == "Take my selfie."){
        console.log("taking selfie");
        speak2();
    }
}

function speak2(){
    var speech2 = window.speechSynthesis;
    var speak_data2 = "taking your selfie in 10 seconds";

    var utterThis2 = new SpeechSynthesisUtterance(speak_data2);
    speech2.speak(utterThis2);
    Webcam.attach(webcam2);

    setTimeout(function()
    {
        capture2();
        download2();
    },10000);
}
var webcam2 = document.getElementById("webcam");
Webcam.set({
    width: 360,
    height: 250,
    image_format: 'jpeg',
    jpeg_quality: 90
 });

 function capture2(){
    Webcam.snap(function(selfie2) {
        document.getElementById("result2").innerHTML = '<img id="snapshot2" src="'+selfie2+'">';
    });
 }

 function download2(){
    link2=document.getElementById("download");
    img2=document.getElementById("snapshot2").src;
    link2.href=img2;
    link2.click();
 }

var SpeechRecognition3=window.webkitSpeechRecognition;
var recognise3= new SpeechRecognition3();

function start3(){
    recognise3.start();
}

recognise3.onresult=function(event){
    console.log(event);
    var content3 = event.results[0][0].transcript;
    document.getElementById("voice_output").innerHTML = content3;
    console.log(content3);
    if(content3 == "Take my selfie."){
        console.log("taking selfie");
        speak3();
    }
}

function speak3(){
    var speech3 = window.speechSynthesis;
    var speak_data3 = "taking your selfie in 15 seconds";

    var utterThis3 = new SpeechSynthesisUtterance(speak_data3);
    speech3.speak(utterThis3);
    Webcam.attach(webcam3);

    setTimeout(function()
    {
        capture3();
        download3();
    },15000);
}
var webcam3 = document.getElementById("webcam");
Webcam.set({
    width: 360,
    height: 250,
    image_format: 'jpeg',
    jpeg_quality: 90
 });

 function capture3(){
    Webcam.snap(function(selfie) {
        document.getElementById("result3").innerHTML = '<img id="snapshot3" src="'+selfie+'">';
    });
 }

 function download(){
    link3=document.getElementById("download");
    img3=document.getElementById("snapshot3").src;
    link3.href=img3;
    link3.click();
 }

